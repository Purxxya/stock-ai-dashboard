
import React, { useState, useMemo, useEffect } from 'react';
import { 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  ReferenceLine, 
  AreaChart,
  Area,
  Line,
  ComposedChart
} from 'recharts';
import { 
  ChevronDown,
  Database,
  BarChart4,
  TrendingUp,
  Network,
  Cpu,
  BrainCircuit,
  Loader2
} from 'lucide-react';
import { Stock, ModelMetric } from '../types';
import { fetchQuantForecast } from '../services/geminiService';

interface QuantViewProps {
  stocks: Stock[];
  initialSelected?: Stock | null;
}

const QuantView: React.FC<QuantViewProps> = ({ stocks, initialSelected }) => {
  const [selectedStock, setSelectedStock] = useState<Stock | null>(initialSelected || stocks[0]);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [activeRange, setActiveRange] = useState('1D');
  const [forecastResponse, setForecastResponse] = useState<any>(null);
  const [isSyncing, setIsSyncing] = useState(false);

  const ranges = ['1D', '15D', '30D'];

  // ดึงข้อมูลทำนายจาก AI เมื่อหุ้นหรือช่วงเวลาเปลี่ยน
  useEffect(() => {
    const updateForecast = async () => {
      if (!selectedStock) return;
      setIsSyncing(true);
      try {
        const result = await fetchQuantForecast(selectedStock.symbol, activeRange, selectedStock.price);
        if (result) setForecastResponse(result);
      } catch (e) {
        console.error("Sync Error", e);
      } finally {
        setIsSyncing(false);
      }
    };
    updateForecast();
  }, [selectedStock, activeRange]);

  // ผสมข้อมูลประวัติจริงกับข้อมูลทำนายจาก AI
  const forecastData = useMemo(() => {
    const basePrice = selectedStock?.price || 100;
    const history = selectedStock?.history || [];
    
    // กรองประวัติให้เหลือจำนวนที่พอเหมาะกับการแสดงผล (15 จุดล่าสุด)
    const recentHistory = history.slice(-15).map(h => ({
      time: h.time,
      fullDate: h.time,
      price: h.price,
      volume: h.volume?.toString() || "0",
      isCutoff: false
    }));

    if (!forecastResponse || !forecastResponse.forecasts || recentHistory.length === 0) {
       return recentHistory;
    }

    // ข้อมูลราคาล่าสุดที่ใช้เป็นจุดเชื่อมต่อ
    const lastActualPoint = recentHistory[recentHistory.length - 1];

    // เพิ่มจุด Cutoff ระหว่างอดีตและอนาคต เพื่อให้เส้นทำนายเชื่อมกับราคาปัจจุบัน
    const cutoffPoint = {
      ...lastActualPoint,
      modelA: lastActualPoint.price, // เริ่มต้นเส้นทำนายจากราคาปัจจุบัน
      modelB: lastActualPoint.price,
      modelC: lastActualPoint.price,
      isCutoff: true,
      time: "NOW"
    };

    // แปลงผลจาก AI เป็นจุดกราฟ
    const futurePoints = forecastResponse.forecasts.map((f: any) => ({
      time: f.label,
      fullDate: f.label,
      modelA: f.modelA,
      modelB: f.modelB,
      modelC: f.modelC,
      volume: "N/A",
      isCutoff: false
    }));

    return [...recentHistory, cutoffPoint, ...futurePoints];
  }, [selectedStock, forecastResponse]);

  const metrics: ModelMetric[] = [
    { name: 'Baseline (Ridge Regression)', mae: 4.25, rmse: 6.12, sharpe: 1.12, winRate: 54 },
    { name: 'Kronos (Price-Action AI)', mae: 3.12, rmse: 4.85, sharpe: 1.85, winRate: 59 },
    { name: 'Chronos-2+ (News Sentiment AI)', mae: 2.45, rmse: 3.22, sharpe: 2.44, winRate: 67 }
  ];

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xl shadow-slate-200/50 min-w-[220px] z-50">
          <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 border-b border-slate-50 pb-2">
            {data.fullDate} {label}
          </div>
          <div className="space-y-2">
            {data.price !== undefined && (
              <div className="flex justify-between items-center">
                <span className="text-[11px] font-bold text-slate-500">Actual Price</span>
                <span className="text-[14px] font-black text-slate-900">฿{data.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
            )}
            {data.modelA !== undefined && (
              <div className="flex justify-between items-center text-slate-400">
                <span className="text-[10px] font-black uppercase tracking-tighter">Baseline Ref</span>
                <span className="text-[12px] font-black">฿{data.modelA.toFixed(2)}</span>
              </div>
            )}
            {data.modelB !== undefined && (
              <div className="flex justify-between items-center text-blue-500">
                <span className="text-[10px] font-black uppercase tracking-tighter">Kronos Predict</span>
                <span className="text-[12px] font-black">฿{data.modelB.toFixed(2)}</span>
              </div>
            )}
            {data.modelC !== undefined && (
              <div className="flex justify-between items-center text-red-600">
                <span className="text-[10px] font-black uppercase tracking-tighter">Chronos-2+ Predict</span>
                <span className="text-[13px] font-black font-mono">฿{data.modelC.toFixed(2)}</span>
              </div>
            )}
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="flex flex-col min-h-full bg-white animate-in fade-in duration-700 rounded-3xl border border-slate-200 shadow-xl overflow-visible">
      {/* Upper Terminal Branding */}
      <div className="p-8 pb-4 bg-white border-b border-slate-100 flex flex-col shrink-0 rounded-t-3xl">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-5">
            <div className="w-12 h-12 bg-slate-900 rounded-2xl flex items-center justify-center text-white font-bold shadow-lg shadow-slate-900/30">
              {isSyncing ? <Loader2 className="animate-spin" size={24} /> : <BrainCircuit size={24} />}
            </div>
            <div>
              <h3 className="text-xl font-black text-slate-900 block uppercase tracking-tighter">Quant Intelligence Engine</h3>
              <p className="text-[10px] text-red-600 font-black uppercase tracking-widest mt-1">
                {isSyncing ? 'Synchronizing Model Outputs...' : 'Horizon Forecasting Pipeline'}
              </p>
            </div>
          </div>

          <div className="relative">
            <button 
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="flex items-center gap-3 px-6 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-[11px] font-black uppercase tracking-tight hover:border-red-600 transition-all shadow-sm"
            >
              <Database size={14} className="text-red-600" />
              {selectedStock?.symbol} Selector
              <ChevronDown size={14} className={`transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} />
            </button>
            
            {isDropdownOpen && (
              <div className="absolute top-full mt-2 right-0 w-64 bg-white border border-slate-200 rounded-2xl shadow-2xl z-[100] max-h-96 overflow-y-auto custom-scrollbar animate-in slide-in-from-top-2 duration-200">
                <div className="p-2 space-y-1">
                  {stocks.map(s => (
                    <button 
                      key={s.symbol}
                      onClick={() => {
                        setSelectedStock(s);
                        setIsDropdownOpen(false);
                      }}
                      className={`flex items-center justify-between w-full px-4 py-2.5 rounded-xl text-left transition-all ${selectedStock?.symbol === s.symbol ? 'bg-red-600 text-white' : 'hover:bg-slate-50 text-slate-600'}`}
                    >
                      <span className="text-[11px] font-black">{s.symbol}</span>
                      <span className={`text-[9px] font-bold ${selectedStock?.symbol === s.symbol ? 'text-red-100' : 'text-slate-400'}`}>฿{s.price.toFixed(2)}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Analysis Content */}
      <div className="p-8 lg:p-12 flex-1">
        <div className="max-w-5xl mx-auto">
          
          <div className="flex items-center gap-2 text-[13px] text-slate-500 font-medium mb-2">
            <span>Market Analysis</span>
            <span><ChevronDown size={10} className="-rotate-90 opacity-40" /></span>
            <span className="font-black text-slate-900">{selectedStock?.symbol} Forecasting</span>
          </div>
          
          <h2 className="text-4xl font-black text-slate-900 tracking-tight">
            {selectedStock?.fullName}
          </h2>

          {/* Current Stats */}
          <div className="mt-4 flex flex-col md:flex-row md:items-end gap-2 md:gap-6">
            <div className="text-6xl font-black text-slate-900 flex items-baseline tracking-tighter">
              <span className="text-4xl mr-1 font-medium">฿</span>
              {selectedStock?.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </div>
            <div className={`text-xl font-black mb-1 px-3 py-1 rounded-xl ${selectedStock && selectedStock.changePercent >= 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
              {selectedStock && selectedStock.changePercent >= 0 ? '+' : ''}{selectedStock?.change.toFixed(2)} ({selectedStock?.changePercent.toFixed(2)}%)
            </div>
          </div>

          {/* Forecast Horizon Selectors */}
          <div className="flex items-center gap-8 border-b border-slate-100 pt-10 pb-1 mb-10">
            {ranges.map(range => (
              <button
                key={range}
                onClick={() => setActiveRange(range)}
                className={`text-[15px] font-black pb-4 transition-all relative px-2 ${activeRange === range ? 'text-red-600' : 'text-slate-300 hover:text-slate-600'}`}
              >
                {range} Prediction
                {activeRange === range && (
                  <div className="absolute bottom-0 left-0 right-0 h-[4px] bg-red-600 rounded-full animate-in slide-in-from-bottom-1 duration-300"></div>
                )}
              </button>
            ))}
          </div>

          {/* Multi-Model Forecast Chart */}
          <div className="relative bg-white pt-6 min-h-[500px]">
            {isSyncing && (
              <div className="absolute inset-0 bg-white/60 backdrop-blur-sm z-20 flex items-center justify-center">
                <div className="flex flex-col items-center gap-4">
                  <Loader2 className="animate-spin text-red-600" size={40} />
                  <span className="text-[12px] font-black text-slate-900 uppercase tracking-widest">Generating Real AI Forecast...</span>
                </div>
              </div>
            )}

            {/* Chart Legend Overlay */}
            <div className="absolute left-0 top-0 z-10 flex gap-6 p-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-slate-900"></div>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Actual</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 border-t-2 border-slate-300 border-dashed w-6"></div>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Baseline</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 border-t-2 border-blue-400 border-dashed w-6"></div>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Kronos</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 border-t-2 border-red-600 border-dashed w-6"></div>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Chronos-2+</span>
              </div>
            </div>

            <div className="h-[480px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={forecastData} margin={{ top: 40, right: 0, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="quantGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#dc2626" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#dc2626" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  
                  <XAxis 
                    dataKey="time" 
                    axisLine={true} 
                    stroke="#f1f5f9"
                    tickLine={false} 
                    tick={{ fill: '#cbd5e1', fontSize: 11, fontWeight: 700 }}
                    interval={activeRange === '1D' ? 4 : 2}
                  />
                  
                  <YAxis 
                    domain={['auto', 'auto']} 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fill: '#cbd5e1', fontSize: 11, fontWeight: 700 }}
                    orientation="right"
                  />

                  <Tooltip content={<CustomTooltip />} cursor={{ stroke: '#f1f5f9', strokeWidth: 1 }} />

                  {/* Cutoff Reference Line */}
                  {forecastData.find(d => d.isCutoff) && (
                    <ReferenceLine 
                      x={forecastData.find(d => d.isCutoff)?.time} 
                      stroke="#0f172a" 
                      strokeWidth={2}
                      label={{ 
                        position: 'top', 
                        value: 'AI FORECAST POINT', 
                        fill: '#0f172a', 
                        fontSize: 9, 
                        fontWeight: 900,
                        dy: -20
                      }}
                    />
                  )}

                  {/* actual path */}
                  <Area 
                    type="monotone" 
                    dataKey="price" 
                    stroke="#0f172a" 
                    strokeWidth={3} 
                    fill="url(#quantGradient)" 
                    animationDuration={1500}
                    connectNulls
                  />

                  {/* Prediction Paths */}
                  <Line 
                    type="monotone" 
                    dataKey="modelA" 
                    stroke="#cbd5e1" 
                    strokeWidth={2} 
                    strokeDasharray="4 4"
                    dot={false}
                    animationDuration={2000}
                    connectNulls
                  />
                  <Line 
                    type="monotone" 
                    dataKey="modelB" 
                    stroke="#3b82f6" 
                    strokeWidth={2} 
                    strokeDasharray="6 3"
                    dot={false}
                    animationDuration={2500}
                    connectNulls
                  />
                  <Line 
                    type="monotone" 
                    dataKey="modelC" 
                    stroke="#dc2626" 
                    strokeWidth={3} 
                    strokeDasharray="8 4"
                    dot={false}
                    animationDuration={3000}
                    connectNulls
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Analytics Metadata Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-16 pb-32">
            
            <div className="bg-slate-50 p-8 rounded-[3rem] border border-slate-200 shadow-sm space-y-8">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-red-600 rounded-2xl text-white">
                  <Cpu size={22} />
                </div>
                <div>
                  <h4 className="text-xl font-black text-slate-900 uppercase tracking-tighter">Model Scoreboard</h4>
                  <p className="text-[11px] text-slate-400 font-bold uppercase tracking-widest">Backtest Performance (Last 90 Days)</p>
                </div>
              </div>
              
              <div className="space-y-4">
                {metrics.map(m => (
                  <div key={m.name} className="flex items-center justify-between p-4 bg-white rounded-2xl border border-slate-100 transition-all hover:border-red-600/20 hover:shadow-lg hover:shadow-red-600/5 group">
                    <div className="flex flex-col">
                      <span className="text-[13px] font-black text-slate-700 group-hover:text-red-600">{m.name}</span>
                      <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Pipeline Node</span>
                    </div>
                    <div className="flex items-center gap-8">
                      <div className="text-right">
                        <div className="text-[10px] font-black text-slate-300 uppercase">MAE</div>
                        <div className="text-[14px] font-black tabular-nums">{m.mae.toFixed(2)}</div>
                      </div>
                      <div className="bg-slate-900 text-white px-4 py-2 rounded-xl text-center min-w-[70px]">
                        <div className="text-[8px] font-black text-slate-500 uppercase">Win Rate</div>
                        <div className="text-[14px] font-black">{m.winRate}%</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-slate-900 p-10 rounded-[3rem] text-white shadow-2xl relative overflow-hidden flex flex-col justify-between group">
               <div className="absolute -top-10 -right-10 opacity-10 group-hover:opacity-20 transition-all duration-700">
                 <TrendingUp size={240} />
               </div>
               
               <div className="relative z-10 space-y-8">
                  <div className="flex items-center gap-4">
                    <div className="p-4 bg-red-600 rounded-3xl text-white shadow-xl shadow-red-600/20 animate-pulse">
                      <Network size={24} />
                    </div>
                    <div>
                      <h4 className="text-2xl font-black uppercase tracking-tighter">Alpha Intelligence</h4>
                      <p className="text-[10px] text-red-500 font-black uppercase tracking-widest">Live Strat Node Insight</p>
                    </div>
                  </div>
                  
                  <div className="p-8 bg-white/5 rounded-[2.5rem] border border-white/5 backdrop-blur-3xl">
                    <p className="text-[16px] text-slate-200 leading-relaxed font-medium italic border-l-4 border-red-600 pl-8">
                      {forecastResponse?.insight || `โมเดลกำลังวิเคราะห์ปัจจัยพื้นฐานและสัญญาณทางเทคนิคสำหรับ ${selectedStock?.symbol} โปรดรอสักครู่...`}
                    </p>
                  </div>
               </div>

               <div className="relative z-10 mt-10 pt-10 border-t border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-4 h-4 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_15px_rgba(16,185,129,0.5)]"></div>
                    <span className="text-[12px] font-black uppercase tracking-[0.2em] text-emerald-500">Live Prediction Active</span>
                  </div>
                  <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest bg-white/5 px-4 py-2 rounded-full border border-white/5">
                    Updated: {new Date().toLocaleTimeString()}
                  </div>
               </div>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
};

export default QuantView;
